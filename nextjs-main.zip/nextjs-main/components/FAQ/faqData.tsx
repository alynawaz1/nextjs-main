import { FAQ } from "@/types/faq";

const faqData: FAQ[] = [
  {
    id: 1,
    quest: "Lorem ipsum dolor sit amet, consectetur",
    ans: "Lorem ipsum dolor sit amet, consectetur.Lorem ipsum dolor sit amet, consectetur.Lorem ipsum dolor sit amet, consectetur.Lorem ipsum dolor sit amet, consectetur.",
  },
  {
    id: 2,
    quest: "Lorem ipsum dolor sit amet, consectetur",
    ans: "Lorem ipsum dolor sit amet, consectetur.Lorem ipsum dolor sit amet, consectetur.Lorem ipsum dolor sit amet, consectetur.Lorem ipsum dolor sit amet, consectetur.",
  },
  {
    id: 3,
    quest: "Lorem ipsum dolor sit amet, consectetur",
    ans: "orem ipsum dolor sit amet, consecteturorem ipsum dolor sit amet, consecteturorem ipsum dolor sit amet, consecteturorem ipsum dolor sit amet.",
  },
];

export default faqData;
