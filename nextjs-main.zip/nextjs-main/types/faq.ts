export type FAQ = {
  id: number;
  quest: string;
  ans: string;
};
